#include <stdio.h>
#include <stdlib.h>

int main() {
    int i = 5;
    int* pI = &i;
    i;
    *pI;
    pI[0];

    int* entierDynamique1 = (int*) malloc(sizeof(int));     // int entier1;
    int* entierDynamique2 = (int*) calloc(3, sizeof(int));  // int entier2 = 0;

    printf(" %d\n", *entierDynamique1);
    printf(" %d\n", *entierDynamique2);
    scanf(" %d", entierDynamique1);
    scanf(" %d", entierDynamique2);
    printf(" %d\n", *entierDynamique1);
    printf(" %d\n", *entierDynamique2);

    // Différents moyens d'accéder aux cases :

    *entierDynamique1;
    entierDynamique1[0];

    // 0x1234 (0x1235 0x1236 0x12347)
    entierDynamique2[0];
    *(entierDynamique2 + 0 * sizeof(int));
    *entierDynamique2;

    // 0x1238 (0x1239 0x123a 0x1234b)
    entierDynamique2[1];
    *(entierDynamique2 + 1 * sizeof(int));

    // 0x123c (0x123d 0x123e 0x1234f)
    entierDynamique2[2];
    *(entierDynamique2 + 2 * sizeof(int));


    free(entierDynamique1);
    free(entierDynamique2);
    return 0;
}
