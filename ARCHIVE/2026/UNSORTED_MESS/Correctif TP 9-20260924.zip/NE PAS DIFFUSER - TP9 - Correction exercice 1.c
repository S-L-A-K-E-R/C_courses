#include <stdio.h>
#include <stdlib.h>

// Ici, l'utilisateur risque d'oublier de récupérer la valeur retournée, et on perd le tableau dynamique :
int* creerTableauV1(int* pTaille) {
    int* t = NULL;
    printf("Combien de cases ?\n");
    scanf("%d", pTaille); // <=> &*pTaille <=> &*&*&*&*&*&*&*&*pTaille
    t = (int*) calloc(*pTaille, sizeof(int));
    return t;
    // ou :
    // return (int*) calloc(*pTaille, sizeof(int)); // évite l'allocation automatique de t
}

void creerTableauV2(int** t, int* pTaille) {
    printf("Combien de cases ?\n");
    scanf("%d", pTaille); // <=> &*pTaille <=> &*&*&*&*&*&*&*&*pTaille
    *t = (int*) calloc(*pTaille, sizeof(int));
}

int main(void) {
    int i = 0;
    int tailleLogique = 0;
    int* tab = creerTableauV1(&tailleLogique);
    for(i = 0; i < tailleLogique; i++) {
        printf("%d, ", tab[i]);
    }
    free(tab);
    tab = NULL;
    tailleLogique = 0;
    printf("\n");
    creerTableauV2(&tab, &tailleLogique);
    for(i = 0; i < tailleLogique; i++) {
        printf("%d, ", tab[i]);
    }
    free(tab);
    tab = NULL;
    return 0;
}