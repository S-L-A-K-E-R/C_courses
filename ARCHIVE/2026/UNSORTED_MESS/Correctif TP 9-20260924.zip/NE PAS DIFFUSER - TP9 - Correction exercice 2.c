#include <stdio.h>
#include <stdlib.h>

int main(void) {
    int nbNotes = 0, i = 0;
    float* notes = NULL;
    float somme = 0.0f;
    printf("Combien allez-vous saisir de notes ?\n");
    scanf(" %d", &nbNotes);
    notes = malloc(nbNotes * sizeof(float));
    for (i = 0; i < nbNotes; i++) {
        printf("Veuillez sairir la note %d :\n", i+1);
        scanf(" %f", &notes[i]);
        somme += notes[i];
    }
    for (i = 0; i < nbNotes; i++) {
        printf("Note %d : %.2f/20\n", i+1, notes[i]);
    }
    printf("Moyenne : %.2f/20\n", somme / (float) nbNotes);
    free(notes);
    return 0;
}