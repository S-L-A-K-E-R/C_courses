#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int** creerMatrice(int* pNbLignes, int* pNbColonnes) {
    int** adrMatrice = NULL;
    printf("Nombre de lignes :\n");
    scanf(" %d", pNbLignes);
    printf("Nombre de colonnes :\n");
    scanf(" %d", pNbColonnes);
    adrMatrice = malloc(*pNbLignes * sizeof(int*));
    printf("Nouvelle allocation dynamique : 0x%x\n", adrMatrice);
    for (int i = 0; i < *pNbLignes; i++) {
        adrMatrice[i] = malloc(*pNbColonnes * sizeof(int));
        printf("Nouvelle allocation dynamique : 0x%x\n", adrMatrice[i]);
    }
    return adrMatrice;
}

void libererMatrice(int*** matrice, int* nbLignes, int* nbColonnes) {
    int i = 0;
    for(i = 0; i < *nbLignes; i++) {
        printf("Liberation : 0x%x\n", (*matrice)[i]);
        free((*matrice)[i]);
        (*matrice)[i] = NULL; // pas utile car case supprimée après par free(matrice)
    }
    printf("Liberation : 0x%x\n", *matrice);
    free(*matrice);
    *matrice = NULL;
    *nbLignes = 0;
    *nbColonnes = 0;
}

void remplissageAleatoire(int** tab2D, int nbLignes, int nbColonnes) {
    for (int i = 0; i < nbLignes; i++) {
        for (int j = 0; j < nbColonnes; j++) {
            tab2D[i][j] = rand() % 256;
        }
    }
}

void afficher(int** tab2D, int nbLignes, int nbColonnes) {
    for (int i = 0; i < nbLignes; i++) {
        for (int j = 0; j < nbColonnes; j++) {
            printf("[%d]\t", tab2D[i][j]);
        }
        printf("\n");
    }
}

int main(void) {
    srand(time(NULL));

    int nbLignes = 0, nbColonnes = 0, i = 0;

    int** matrice = creerMatrice(&nbLignes, &nbColonnes);
    // RISQUE : avec cette fonction, on peut très bien faire ça :
    //int** matrice = NULL;
    //creerMatrice(&nbLignes, &nbColonnes); // on a oublié de récupérer l'adresse du tableau dynamique 2D, il est perdu...
    // SOLUTION : prendre le pointeur matrice par adresse pour lui donner directement l'adresse du tableau dynamique 2D :
    //int** matrice = NULL;
    //creerMatriceV2(&matrice, &nbLignes, &nbColonnes); // c'est ce qu'on a fait pour la procédure libererMatrice.

    afficher(matrice, nbLignes, nbColonnes);
    remplissageAleatoire(matrice, nbLignes, nbColonnes);
    afficher(matrice, nbLignes, nbColonnes);

    printf("Adresse contenue dans matrice: 0x%x\n", matrice);
    libererMatrice(&matrice, &nbLignes, &nbColonnes);
    printf("Adresse contenue dans matrice: 0x%x\n", matrice);
    return 0;
}